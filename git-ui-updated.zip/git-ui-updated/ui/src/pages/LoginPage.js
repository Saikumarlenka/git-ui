import React from 'react'
import Signin from '../features/auth/Signin'

const LoginPage = () => {
  return (
    <Signin />
  )
}

export default LoginPage