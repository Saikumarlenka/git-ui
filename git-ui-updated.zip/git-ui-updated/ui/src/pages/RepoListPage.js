import React from 'react'
import RepoList from '../features/repo/Repolist'


const RepoListPage = () => {
  return (
    <RepoList />
  )
}

export default RepoListPage