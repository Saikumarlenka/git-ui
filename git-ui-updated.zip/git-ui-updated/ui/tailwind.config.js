module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./node_modules/antd/**/*.{js,css}", 
  ],
  theme: {
    extend: {
    
    },
  },
  plugins: [],
};
